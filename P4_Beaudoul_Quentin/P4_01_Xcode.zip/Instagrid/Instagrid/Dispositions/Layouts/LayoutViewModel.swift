//
//  LayoutViewModel.swift
//  Instagrid
//
//  Created by Quentin Beaudoul on 26/10/2021.
//

import Foundation
import UIKit

class LayoutViewModel {
    
    var images : [UIImage?] = [nil, nil, nil, nil]
    var currentViewTag : Int?
}
