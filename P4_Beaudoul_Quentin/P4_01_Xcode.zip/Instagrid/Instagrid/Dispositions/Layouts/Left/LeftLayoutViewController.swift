//
//  LeftLayoutViewController.swift
//  Instagrid
//
//  Created by Quentin Beaudoul on 26/10/2021.
//

import UIKit

class LeftLayoutViewController: LayoutViewController {
    
}
