//
//  MainViewController.swift
//  Instagrid
//
//  Created by Quentin Beaudoul on 26/10/2021.
//

import Foundation
import UIKit

class MainViewModel {
    var images: [UIImage]?
}

