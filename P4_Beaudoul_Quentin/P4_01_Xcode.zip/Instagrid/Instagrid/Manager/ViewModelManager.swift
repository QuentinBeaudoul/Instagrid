//
//  ViewModelManager.swift
//  Instagrid
//
//  Created by Quentin on 27/10/2021.
//

import Foundation

class ViewModelManager {
    
    static let viewModel = LayoutViewModel()
    
    private init() {}
}
